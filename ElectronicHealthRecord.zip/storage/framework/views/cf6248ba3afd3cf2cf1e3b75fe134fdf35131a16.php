<?php $__env->startSection('title', 'Dashboard | Electronic Health Record'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-heading p-4 bg-light">
        <h2 class="text-success ">APPOINTMENTS HISTORY</h2>
    </div>
    <div class="container-fluid mt-3 mb-5">
        <?php if(Auth::user()->role_id == 3): ?>
            <a href="<?php echo e(route('patients.book-appointment')); ?>"><button class="btn btn-success mb-2">Book Appointment</button></a>
        <?php endif; ?>
            <div class="table-responsive">
            <table id="example" class="table table-striped nowrap" style="width:100%">
                <thead>
                    <tr>
                        <th>Doctor Name</th>
                        <th>Patient Name</th>
                        <th>Specialization</th>
                        <th>Consultancy Fee</th>
                        <th>Appointment Date / Time</th>
                        <th>Appointment Creation Date</th>
                        <th></th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($appointment->doctor->user->name); ?></td>
                            <td><?php echo e($appointment->patient->user->name); ?></td>
                            <td><?php echo e($appointment->doctor_specialization); ?></td>
                            <td><?php echo e($appointment->consultancy_fees); ?></td>
                            <td><?php echo e($appointment->appointment_date); ?> / <?php echo e($appointment->appointment_time); ?></td>
                            <td><?php echo e($appointment->created_at); ?></td>
                            <td><?php echo e($appointment->age); ?></td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ElectronicHealthRecord\resources\views/appointment_history.blade.php ENDPATH**/ ?>