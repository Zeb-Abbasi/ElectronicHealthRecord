<h1>Hello World</h1>
<?php /**PATH C:\xampp\htdocs\laravel\ElectronicHealthRecord\resources\views/admin/user.blade.php ENDPATH**/ ?>