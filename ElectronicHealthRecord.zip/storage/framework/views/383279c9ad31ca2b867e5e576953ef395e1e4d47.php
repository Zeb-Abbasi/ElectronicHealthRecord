

<?php $__env->startSection('title', 'Dashboard | Electronic Health Record'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-heading p-4 bg-light">
        <h2 class="text-success ">BETWEEN DATES | REPORTS</h2>
    </div>
    <div class="container-fluid mt-3 mb-5">
        <form id="dataForm" action="<?php echo e(route('reports')); ?>" method="GET">

            <div class="form-group mb-3">
                <label for="fromDate" class="form-label">From Date:</label>
                <input type="date" class="form-control" id="fromDate" name="fromDate">
                <span id="fromDate_error" class="error-message"></span>
            </div>
            <div class="form-group mb-3">
                <label for="toDate" class="form-label">To Date:</label>
                <input type="date" class="form-control" id="toDate" name="toDate">
                <span id="toDate_error" class="error-message"></span>
            </div>
            



            <button class="btn btn-primary btn-lg btn-block btn-success my-3" type="submit">
                Submit
            </button>

        </form>
    </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ElectronicHealthRecord\resources\views/reports-form.blade.php ENDPATH**/ ?>