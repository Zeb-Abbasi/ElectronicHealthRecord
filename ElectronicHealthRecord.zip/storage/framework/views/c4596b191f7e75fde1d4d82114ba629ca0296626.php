<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">

</head>

<body>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>















    <script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script> 
    
    <script type="text/javascript"  src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>
    <script type="text/javascript"  src="<?php echo e(asset('js/isotope.pkgd.min.js')); ?>"></script>
    <script type="text/javascript"  src="<?php echo e(asset('js/filter.js')); ?>"></script>
   
    
    <script>
        $(document).ready(function() {
            $('#portfolioTabs a').click(function(e) {
                e.preventDefault();
                $(this).tab('show');
            });
        });
    </script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel\ElectronicHealthRecord\resources\views/layouts/master.blade.php ENDPATH**/ ?>