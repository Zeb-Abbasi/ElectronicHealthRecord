<?php $__env->startSection('title', 'Dashboard | Electronic Health Record'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h1 class="mt-5 fw-normal text-uppercase fs-2">Dashboard</h1>
        <?php echo $__env->make('common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div class="row mt-5">

            <?php
                // $patient_tiles = ['Profile', 'Appointments', 'Book Appointment'];
                $patient_tiles = [
                    [
                        'title' => 'My profile',
                        'icon' => 'fa-solid fa-house',
                        'description' => 'Update Profile',
                        'url' => route('patients.edit', ['id' => Auth::user()->id]),
                    ],
                    [
                        'title' => 'My Appointments',
                        'icon' => 'fas fa-calendar fa-2x text-gray-300',
                        'description' => ' View Appointment History ',
                        'url' => route('patients.appointments'),
                    ],
                    [
                        'title' => 'Book My Appointment',
                        'icon' => 'fas fa-calendar-plus fa-2x text-gray-300',
                        'description' => ' Book Appointment ',
                        'url' => route('patients.book-appointment'),
                    ],
                ];
                $admin_tiles = [
                    [
                        'title' => 'Manage Patients',
                        'icon' => 'fa-solid fa-house',
                        'description' => 'Manage Patients',
                        'url' => route('patients.index'),
                    ],
                    [
                        'title' => 'Manage Doctors',
                        'icon' => 'fas fa-calendar fa-2x text-gray-300',
                        'description' => ' Manage Doctors ',
                        'url' => route('doctors.index'),
                    ],
                    [
                        'title' => 'Appointments',
                        'icon' => 'fas fa-calendar-plus fa-2x text-gray-300',
                        'description' => ' View Appointment History',
                        'url' => route('admin-appointments'),
                    ],
                ];
                $doctor_tiles = [
                    [
                        'title' => 'My profile',
                        'icon' => 'fa-solid fa-house',
                        'description' => 'Update Profile',
                        'url' => route('doctors.edit', ['id' => Auth::user()->id]),
                    ],
                    [
                        'title' => 'My Appointments',
                        'icon' => 'fas fa-calendar fa-2x text-gray-300',
                        'description' => ' View Appointment History ',
                        'url' => route('doctors.appointments'),
                    ],
                ];
                // $doctor_tiles = ['Profile', 'Appointments'];
                // $admin_tiles = ['Manage Patients', 'Manage Doctors', 'Appointments'];
            ?>
            <?php if(Auth::user()->role_id == 1): ?>
            <?php $__currentLoopData = $admin_tiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin_tile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-3 col-md-6 mb-4">
                <a class="text-decoration-none" href="<?php echo e($admin_tile['url']); ?>">
                    <div class="card border-left-primary shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs fw-bold text-primary text-uppercase mb-1">
                                        <?php echo e($admin_tile['description']); ?>

                                    </div>
                                    <div class="h5 mb-0 fw-bold text-gray-800"><?php echo e($admin_tile['title']); ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="<?php echo e($admin_tile['icon']); ?>"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(Auth::user()->role_id == 2): ?>
                <?php $__currentLoopData = $doctor_tiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor_tile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-3 col-md-6 mb-4">
                        <a class="text-decoration-none" href="<?php echo e($doctor_tile['url']); ?>">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs fw-bold text-primary text-uppercase mb-1">
                                                <?php echo e($doctor_tile['description']); ?>

                                            </div>
                                            <div class="h5 mb-0 fw-bold text-gray-800"><?php echo e($doctor_tile['title']); ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="<?php echo e($doctor_tile['icon']); ?>"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(Auth::user()->role_id == 3): ?>
                <?php $__currentLoopData = $patient_tiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient_tile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-3 col-md-6 mb-4">
                        <a class="text-decoration-none" href="<?php echo e($patient_tile['url']); ?>">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs fw-bold text-primary text-uppercase mb-1">
                                                <?php echo e($patient_tile['description']); ?>

                                            </div>
                                            <div class="h5 mb-0 fw-bold text-gray-800"><?php echo e($patient_tile['title']); ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="<?php echo e($patient_tile['icon']); ?>"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ElectronicHealthRecord\resources\views/dashboard.blade.php ENDPATH**/ ?>