<?php $__env->startSection('title', 'Dashboard | Electronic Health Record'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-heading p-4 bg-light">
        <h2 class="text-success "><?php echo e(isset($patient) ? 'EDIT' : 'ADD'); ?> PATIENTS</h2>
    </div>
    <div class="container-fluid mt-3 mb-5">
        <form id="dataForm" action="<?php echo e(isset($patient) ? route('patients.update', $patient->id) : route('patients.store')); ?>"
            method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(isset($patient)): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>

            <div class="form-group mt-3">
                <label for="doctor">Doctor</label>
                <select class="form-select mt-1" id="doctor" name="doctor_id" required>
                    <option value="">Select Doctor</option>
                    <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($doctor->id); ?>"
                            <?php echo e(isset($doctor) && $doctor->user->name == $doctor->user->name ? 'selected' : ''); ?>>
                            <?php echo e($doctor->user->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span id="doctor_id_error" class="error-message"></span>
            </div>

            <div class="form-group mt-3">
                <label for="patient">Name</label>
                <input type="text" class="form-control mt-1" id="name" name="name"
                    value="<?php echo e($patient->user->name ?? ''); ?>" required>
                <span id="name_error" class="error-message"></span>
            </div>
            <div class="form-group mt-3">
                <label for="email">Email</label>
                <input type="email" class="form-control mt-1" id="email" name="email"
                    value="<?php echo e($patient->user->email ?? ''); ?>" required>
                <span id="email_error" class="error-message"></span>
            </div>
            <div class="form-group mt-3">
                <label for="contact_no">Contact No</label>
                <input type="text" class="form-control mt-1" id="contact_no" name="contact_no"
                    value="<?php echo e($patient->contact_no ?? ''); ?>" required>
                <span id="contact_no_error" class="error-message"></span>
            </div>
            <div class="form-group mt-3">
                <label for="address">Address</label>
                <input type="text" class="form-control mt-1" id="address" name="address"
                    value="<?php echo e($patient->address ?? ''); ?>" required>
                <span id="address_error" class="error-message"></span>
            </div>

            

            <div class="form-group mt-3">
                <label for="gender">Gender</label><br>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" id="gender_male" name="gender" value="male"
                        <?php echo e((isset($patient) && $patient->gender == 'male') ? 'checked' : ''); ?> required>
                    <label class="form-check-label" for="gender_male">Male</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" id="gender_female" name="gender" value="female"
                        <?php echo e((isset($patient) && $patient->gender == 'female') ? 'checked' : ''); ?> required>
                    <label class="form-check-label" for="gender_female">Female</label>
                </div>
                <span id="gender_error" class="error-message"></span>
            </div>

            <div class="form-group mt-3">
                <label for="age">Age</label>
                <input type="number" class="form-control mt-1" id="age" name="age"
                    value="<?php echo e($patient->age ?? ''); ?>" required>
                <span id="age_error" class="error-message"></span>
            </div>


            <div class="my-3">
                <label for="image" class="form-label">Select an image:</label>
                <input type="file" class="form-control" id="image" name="image">
                <?php if(isset($patient) && $patient->image): ?>
                    <img class="mt-3" id="uploadedImage" src="<?php echo e(asset($patient->image)); ?>" alt="Uploaded Image"
                        width="230" height="200">
                <?php else: ?>
                    <img class="d-none mt-3" id="uploadedImage" src="default-placeholder.jpg"
                        alt="Default Placeholder Image" width="230" height="200">
                <?php endif; ?>
            </div>

            <?php if(!isset($patient)): ?>
                <div class="form-group mt-3">
                    <label for="password">Password</label>
                    <input type="password" class="form-control mt-1" id="password" name="password" required>
                    <span id="password_error" class="error-message"></span>
                </div>

                <div class="form-group mt-3">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" class="form-control mt-1" id="confirm_password" name="confirm_password"
                        required>
                    <span id="confirm_password_error" class="error-message"></span>
                </div>
            <?php endif; ?>



            <button class="btn btn-primary btn-lg btn-block btn-success my-3" type="submit">
                <?php echo e(isset($patient) ? 'Update Patient' : 'Add Patient'); ?>

            </button>

        </form>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        //////////////////////////////////////////////new code

        $(document).ready(function() {
            $('#image').change(function(e) {
                var file = e.target.files[0];
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#uploadedImage').attr('src', e.target.result);
                    $('#uploadedImage').removeClass('d-none');
                };

                if (file) {
                    reader.readAsDataURL(file);
                } else {
                    $('#uploadedImage').addClass('d-none');
                }
            });

            // Form submit event
            $('#dataForm').on('submit', function(event) {
                event.preventDefault();
                var formData = new FormData(this);

                var route =
                    "<?php echo e(isset($patient) ? route('patients.update', $patient->id) : route('patients.store')); ?>";

                $.ajax({
                    url: route,
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.error) {
                            validationError(response.validation_errors);
                            if (response.message) {
                                printErrorMsg(response.message);
                            }
                        } else {
                            toastr.options = {
                                "closeButton": true,
                                "progressBar": true
                            }
                            toastr.success(response.message, '');
                            setTimeout(function() {
                                window.location.href = "<?php echo e(route('patients.index')); ?>";
                            }, 2000);

                        }
                    },
                    error: function(xhr) {
                        // Handle the error
                        console.log(xhr.responseText);
                    }
                });

                function validationError(errors) {
                    $.each(errors, function(field, messages) {
                        $.each(messages, function(index, message) {
                            $('#' + field + '_error').text(errors[field][0]);
                        });
                    });
                }

                function printErrorMsg(errors) {
                    $('.invalid-error').text(errors).removeClass('d-none');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ElectronicHealthRecord\resources\views/admin/patients/patient.blade.php ENDPATH**/ ?>