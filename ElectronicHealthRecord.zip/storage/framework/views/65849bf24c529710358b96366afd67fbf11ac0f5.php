<?php $__env->startSection('title', 'Dashboard | Electronic Health Record'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-heading p-4 bg-light">
        <h2 class="text-success ">PATIENT</h2>
    </div>
    <div class="container-fluid mt-3 mb-5">
        <h3 class="text-success fw-bold">Patient Reports</h3>
        <div class="text-end">
            <a href="<?php echo e(route('download.pdf', ['patientId' => $report->id])); ?>" class="btn btn-success mb-2" target="_blank">Download PDF</a>
        </div>
        <div class="row">
            <div class="col-lg-3 d-flex flex-column">
                <div class="flex-grow-1">
                    <img src="<?php echo e(asset($report->image)); ?>" alt="" class="w-100 h-100 object-fit-cover">
                </div>
            </div>
            <div class="col-lg-9">
                <div class="table-responsive mt-3 mt-lg-0">
                    <table class="table table-bordered mb-0" style="width: 100%">
                        <thead>
                            <tr>
                                <th colspan="4" class="text-center fs-5 text-secondary">Patient Info</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th class="text-secondary">Patient Name</th>
                                <td><?php echo e($report->user->name); ?></td>
                                <th class="text-secondary">Patient Email</th>
                                <td><?php echo e($report->user->email); ?></td>
                            </tr>
                            <tr>
                                <th class="text-secondary">Patient Mobile Number</th>
                                <td><?php echo e($report->contact_no); ?></td>
                                <th class="text-secondary">Patient Address</th>
                                <td><?php echo e($report->address); ?></td>
                            </tr>
                            <tr>
                                <th class="text-secondary">Patient Gender</th>
                                <td><?php echo e($report->gender); ?></td>
                                <th class="text-secondary">Patient Age</th>
                                <td><?php echo e($report->age); ?></td>
                            </tr>
                            <tr>
                                <th class="text-secondary">Patient Medical History (if any)</th>
                                <td><?php echo e($report->med_his); ?></td>
                                <th class="text-secondary">Patient Reg Date</th>
                                <td><?php echo e($report->created_at); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <table class="table  table-bordered mt-4" style="width:100%">
            <thead>
                <th colspan="6" class="text-center fs-5 text-secondary">Medical History</th>
            </thead>
            <tbody>
                <tr class="text-secondary">
                    <th>Blood Pressure</th>
                    <th>Weight</th>
                    <th>Blood Sugar</th>
                    <th>Body Temprature</th>
                    <th>Medical Prescription</th>
                    <th>Visit Date</th>
                </tr>
                
                    

                <?php $__currentLoopData = $medicalHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medical_history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($medical_history->blood_pressure); ?></td>
                    <td><?php echo e($medical_history->weight); ?></td>
                    <td><?php echo e($medical_history->blood_sugar); ?></td>
                    <td><?php echo e($medical_history->temperature); ?></td>
                    <td><?php echo e($medical_history->treatment); ?></td>
                    <td><?php echo e($medical_history->admission_date); ?></td>
                <tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
        </table>
    </div>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>

        // $(document).ready(function() {

        // });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ElectronicHealthRecord\resources\views/single_report.blade.php ENDPATH**/ ?>