<?php $__env->startSection('title', 'Dashboard | Electronic Health Record'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-heading p-4 bg-light">
        <h2 class="text-success ">PATIENT</h2>
    </div>
    <div class="container-fluid mt-3 mb-5">

        <h3 class="text-success fw-bold mb-5">Patient Details</h3>
        <div class="row">
            <div class="col-lg-3 d-flex flex-column">
                <div class="flex-grow-1">
                    <img src="<?php echo e(asset($patient->image)); ?>" alt="" class="w-100 h-100 object-fit-cover">
                </div>
            </div>
            <div class="col-lg-9">
                <div class="table-responsive mt-3 mt-lg-0">
                    <table class="table table-bordered mb-0" style="width: 100%">
                        <thead>
                            <tr>
                                <th colspan="4" class="text-center fs-5 text-secondary">Patient Info</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th class="text-secondary">Patient Name</th>
                                <td><?php echo e($patient->user->name); ?></td>
                                <th class="text-secondary">Patient Email</th>
                                <td><?php echo e($patient->user->email); ?></td>
                            </tr>
                            <tr>
                                <th class="text-secondary">Patient Mobile Number</th>
                                <td><?php echo e($patient->contact_no); ?></td>
                                <th class="text-secondary">Patient Address</th>
                                <td><?php echo e($patient->address); ?></td>
                            </tr>
                            <tr>
                                <th class="text-secondary">Patient Gender</th>
                                <td><?php echo e($patient->gender); ?></td>
                                <th class="text-secondary">Patient Age</th>
                                <td><?php echo e($patient->age); ?></td>
                            </tr>
                            <tr>
                                <th class="text-secondary">Patient Medical History (if any)</th>
                                <td><?php echo e($patient->med_his); ?></td>
                                <th class="text-secondary">Patient Reg Date</th>
                                <td><?php echo e($patient->created_at); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <table class="table  table-bordered mt-4" style="width:100%">
            <thead>
                <th colspan="6" class="text-center fs-5 text-secondary">Medical History</th>
            </thead>
            <tbody>
                <tr class="text-secondary">
                    <th>Blood Pressure</th>
                    <th>Weight</th>
                    <th>Blood Sugar</th>
                    <th>Body Temprature</th>
                    <th>Medical Prescription</th>
                    <th>Visit Date</th>
                </tr>
                
                    
                <?php $__currentLoopData = $medicalHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medical_history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($medical_history->blood_pressure); ?></td>
                    <td><?php echo e($medical_history->weight); ?></td>
                    <td><?php echo e($medical_history->blood_sugar); ?></td>
                    <td><?php echo e($medical_history->temperature); ?></td>
                    <td><?php echo e($medical_history->treatment); ?></td>
                    <td><?php echo e($medical_history->admission_date); ?></td>
                <tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
        </table>
        <div class="text-center">
            <?php if(Auth::user()->role_id == 1 || Auth::user()->role_id == 3): ?>
            <?php elseif(Auth::user()->role_id == 2): ?>
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#medicalModal">Add Medical History</button>
            <?php endif; ?>
        </div>
    </div>

<!-- Modal -->
<div class="modal fade" id="medicalModal" tabindex="-1" aria-labelledby="medicalModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="page-heading p-4 bg-light">
                    <h2 class="text-success ">ADD MEDICAL HISTORY</h2>
                </div>
                <div class="container-fluid mt-3 mb-5">
                    <form id="createMedical" action="<?php echo e(route('doctors.create-medical-history')); ?>"
                        method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group mt-3">
                            <label for="diagnosis">Diagnosis</label>
                            <input type="text" class="form-control mt-1" id="diagnosis" name="diagnosis"
                                 required>
                            <span id="diagnosis_error" class="error-message"></span>
                        </div>
                        <div class="form-group mt-3">
                            <label for="blood_pressure">Blood Pressure</label>
                            <input type="text" class="form-control mt-1" id="blood_pressure" name="blood_pressure"
                                 required>
                            <span id="blood_pressure_error" class="error-message"></span>
                        </div>
                        <div class="form-group mt-3">
                            <label for="blood_sugar">Blood Sugar</label>
                            <input type="text" class="form-control mt-1" id="blood_sugar" name="blood_sugar"
                                 required>
                            <span id="blood_sugar_error" class="error-message"></span>
                        </div>
                        <div class="form-group mt-3">
                            <label for="weight">Weight</label>
                            <input type="text" class="form-control mt-1" id="weight" name="weight"
                                 required>
                            <span id="weight_error" class="error-message"></span>
                        </div>
                        <div class="form-group mt-3">
                            <label for="temperature">Temperature</label>
                            <input type="text" class="form-control mt-1" id="temperature" name="temperature"
                                 required>
                            <span id="temperature_error" class="error-message"></span>
                        </div>
                        <div class="form-group mt-3">
                            <label for="treatment">Treatment</label>
                            <input type="text" class="form-control mt-1" id="treatment" name="treatment"
                                 required>
                            <span id="treatment_error" class="error-message"></span>
                        </div>
                        <div class="form-group mt-3">
                            <label for="admission_date" class="form-label">Admission Date</label>
                            <input type="date" class="form-control" id="admission_date" name="admission_date">
                            <span id="admission_date_error" class="error-message"></span>
                        </div>
                        <input type="hidden" name="patient_id" value="<?php echo e($patient->id); ?>">
                        <div class="form-group mt-3">
                            <label for="discharge_date" class="form-label">Discharge Date</label>
                            <input type="date" class="form-control" id="discharge_date" name="discharge_date">
                            <span id="discharge_date_error" class="error-message"></span>
                        </div>
                        <div class="mt-5 d-flex justify-content-end">
                            <button class="me-2 btn btn-primary  btn-success" type="submit">
                                Submit
                            </button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" aria-label="Close">Cancel</button>

                        </div>
                    </form>
                </div>
            </div>
            
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        //////////////////////////////////////////////new code


        $(document).ready(function() {
            $('#createMedical').on('submit', function(event) {
                event.preventDefault();
                var formData = new FormData(this);


                $.ajax({
                    url: "<?php echo e(route('doctors.create-medical-history')); ?>",
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.error) {
                            validationError(response.validation_errors);
                            if (response.message) {
                                printErrorMsg(response.message);
                            }
                        } else {
                            toastr.options = {
                                "closeButton": true,
                                "progressBar": true
                            }
                            toastr.success(response.message, '');
                            setTimeout(function() {
                                window.location.href = "<?php echo e(route('patients.show', $patient->id)); ?>";
                            }, 2000);
                        }
                    },
                    error: function(xhr) {
                        // Handle the error
                        console.log(xhr.responseText);
                    }
                });

                function validationError(errors) {
                    $.each(errors, function(field, messages) {
                        $.each(messages, function(index, message) {
                            $('#' + field + '_error').text(errors[field][0]);
                        });
                    });
                }

                function printErrorMsg(errors) {
                    $('.invalid-error').text(errors).removeClass('d-none');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ElectronicHealthRecord\resources\views/admin/patients/show.blade.php ENDPATH**/ ?>