

<?php $__env->startSection('title', 'Dashboard | Electronic Health Record'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-heading p-4 bg-light">
        <h2 class="text-success ">DOCTOR</h2>
    </div>
    <div class="container-fluid mt-3 mb-5">

        <h3 class="text-success fw-bold mb-5">Doctor Details</h3>
        <div class="row">
            
            <div class="table-responsive mt-3 mt-lg-0">
                <table class="table table-bordered mb-0" style="width: 100%">
                    <thead>
                        <tr>
                            <th colspan="4" class="text-center fs-5 text-secondary">Doctor Info</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th class="text-secondary">Doctor Name</th>
                            <td><?php echo e($doctor->user->name); ?></td>
                            <th class="text-secondary">Doctor Email</th>
                            <td><?php echo e($doctor->user->email); ?></td>
                        </tr>
                        <tr>
                            <th class="text-secondary">Doctor Mobile Number</th>
                            <td><?php echo e($doctor->contact_no); ?></td>
                            <th class="text-secondary">Doctor Address</th>
                            <td><?php echo e($doctor->address); ?></td>
                        </tr>
                        <tr>
                            <th class="text-secondary">Doctor Gender</th>
                            <td><?php echo e($doctor->gender); ?></td>
                            <th class="text-secondary">Doctor Age</th>
                            <td><?php echo e($doctor->age); ?></td>
                        </tr>
                        <tr>
                            <th class="text-secondary">Doctor Medical History (if any)</th>
                            <td><?php echo e($doctor->med_his); ?></td>
                            <th class="text-secondary">Doctor Reg Date</th>
                            <td><?php echo e($doctor->created_at); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
        </div>


    </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ElectronicHealthRecord\resources\views/admin/doctors/show.blade.php ENDPATH**/ ?>